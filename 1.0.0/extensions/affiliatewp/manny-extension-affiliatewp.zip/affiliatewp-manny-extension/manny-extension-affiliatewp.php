<?php
/**
 * Plugin Name: Manny Extension - AffiliateWP Integration
 * Description: Affiliate accounts, referrals, and entitlements powered by AffiliateWP.
 * Version: 1.0.0
 * Requires PHP: 8.1
 * Text Domain: manny-rest-route-manager
 */

if (!defined('ABSPATH')) {
    return;
}

if (!function_exists('manny_extension_affiliatewp_dependency_notice')) {
    function manny_extension_affiliatewp_dependency_notice($message)
    {
        if (!function_exists('esc_html')) {
            return;
        }
        echo '<div class="notice notice-error"><p>' . esc_html($message) . '</p></div>';
    }
}

if (!function_exists('manny_extension_affiliatewp_check_dependencies')) {
    function manny_extension_affiliatewp_check_dependencies()
    {
        $messages = [];
        if (!defined('MANNY_RRM_VERSION')) {
            $messages[] = 'Please activate the Manny Rest Route Manager plugin for this extension.';
        }

        $requiredPlugin = 'affiliate-wp/affiliate-wp.php';
        if ($requiredPlugin !== '') {
            if (!function_exists('is_plugin_active') && file_exists(ABSPATH . 'wp-admin/includes/plugin.php')) {
                include_once ABSPATH . 'wp-admin/includes/plugin.php';
            }
            if (!function_exists('is_plugin_active') || !is_plugin_active($requiredPlugin)) {
                $messages[] = 'Required plugin ' . $requiredPlugin . ' is not active.';
            }
        }

        foreach ($messages as $message) {
            add_action('admin_notices', function () use ($message) {
                manny_extension_affiliatewp_dependency_notice($message);
            });
        }
    }
}

manny_extension_affiliatewp_check_dependencies();
