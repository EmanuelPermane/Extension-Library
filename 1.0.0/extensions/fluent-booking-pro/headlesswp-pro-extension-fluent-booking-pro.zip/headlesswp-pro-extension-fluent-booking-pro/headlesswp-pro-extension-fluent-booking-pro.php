<?php
/**
 * Plugin Name: HeadlessWP Pro Extension - FluentBooking Pro
 * Description: Registers FluentBooking Pro as a supported dependency for bookings.
 * Version: 1.0.0
 * Requires PHP: 8.1
 * Text Domain: headlesswp-pro
 */

if (!defined('ABSPATH')) {
    return;
}

if (!function_exists('headlesswp_extension_fluent_booking_pro_dependency_notice')) {
    function headlesswp_extension_fluent_booking_pro_dependency_notice($message): void
    {
        if (!function_exists('esc_html')) {
            return;
        }

        echo '<div class="notice notice-error"><p>' . esc_html($message) . '</p></div>';
    }
}

if (!function_exists('headlesswp_extension_fluent_booking_pro_required_plugin')) {
    function headlesswp_extension_fluent_booking_pro_required_plugin(): string
    {
        return 'fluent-booking-pro/fluent-booking-pro.php';
    }
}

if (!function_exists('headlesswp_extension_fluent_booking_pro_has_core')) {
    function headlesswp_extension_fluent_booking_pro_has_core(): bool
    {
        return defined('HEADLESSWP_PRO_VERSION');
    }
}

if (!function_exists('headlesswp_extension_fluent_booking_pro_is_required_plugin_active')) {
    function headlesswp_extension_fluent_booking_pro_is_required_plugin_active(): bool
    {
        $requiredPlugin = headlesswp_extension_fluent_booking_pro_required_plugin();

        if ($requiredPlugin === '') {
            return true;
        }

        if (!function_exists('is_plugin_active') && file_exists(ABSPATH . 'wp-admin/includes/plugin.php')) {
            include_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        return function_exists('is_plugin_active') && is_plugin_active($requiredPlugin);
    }
}

if (!function_exists('headlesswp_extension_fluent_booking_pro_dependencies_met')) {
    function headlesswp_extension_fluent_booking_pro_dependencies_met(): bool
    {
        return headlesswp_extension_fluent_booking_pro_has_core()
            && headlesswp_extension_fluent_booking_pro_is_required_plugin_active();
    }
}

add_action('plugins_loaded', static function (): void {
    $requiredPlugin = headlesswp_extension_fluent_booking_pro_required_plugin();

    if (!headlesswp_extension_fluent_booking_pro_has_core()) {
        add_action('admin_notices', static function () {
            headlesswp_extension_fluent_booking_pro_dependency_notice('HeadlessWP Pro is not active. Activate HeadlessWP Pro, then reactivate this extension.');
        });

        return;
    }

    if ($requiredPlugin !== '' && !headlesswp_extension_fluent_booking_pro_is_required_plugin_active()) {
        add_action('admin_notices', static function () use ($requiredPlugin) {
            headlesswp_extension_fluent_booking_pro_dependency_notice('Required plugin ' . $requiredPlugin . ' is not active. Activate it, then try again.');
        });
    }
}, 20, 0);

add_action('headlesswp_pro_register_extension', static function ($registry): void {
    if (!headlesswp_extension_fluent_booking_pro_dependencies_met()) {
        return;
    }

    $providerClass = 'HeadlessWPPro\Extensions\FluentBookingExtensionProvider';

    if (!class_exists($providerClass)) {
        add_action('admin_notices', static function () use ($providerClass): void {
            headlesswp_extension_fluent_booking_pro_dependency_notice(
                'This HeadlessWP Pro extension package is incompatible with the active HeadlessWP Pro version: provider class ' . $providerClass . ' is missing.'
            );
        });

        return;
    }

    try {
        $provider = new $providerClass();
    } catch (\Throwable $throwable) {
        headlesswp_extension_fluent_booking_pro_dependency_notice('Failed to initialize extension provider: ' . $throwable->getMessage());

        return;
    }

    if (is_object($registry) && method_exists($registry, 'register')) {
        $registry->register($provider, 'external');
    }
}, 10, 1);
