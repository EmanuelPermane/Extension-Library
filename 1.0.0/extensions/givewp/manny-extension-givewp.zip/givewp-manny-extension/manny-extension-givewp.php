<?php
/**
 * Plugin Name: Manny Extension - GiveWP
 * Description: Integrates GiveWP donation history into Manny entitlements.
 * Version: 1.0.0
 * Requires PHP: 8.1
 * Text Domain: manny-rest-route-manager
 */

if (!defined('ABSPATH')) {
    return;
}

if (!function_exists('manny_extension_givewp_dependency_notice')) {
    function manny_extension_givewp_dependency_notice($message)
    {
        if (!function_exists('esc_html')) {
            return;
        }
        echo '<div class="notice notice-error"><p>' . esc_html($message) . '</p></div>';
    }
}

if (!function_exists('manny_extension_givewp_check_dependencies')) {
    function manny_extension_givewp_check_dependencies(bool $silent = false)
    {
        $messages = [];
        if (!defined('MANNY_RRM_VERSION')) {
            $messages[] = 'Please activate the Manny Rest Route Manager plugin for this extension.';
        }

        $requiredPlugin = 'givewp/givewp.php';
        if ($requiredPlugin !== '') {
            if (!function_exists('is_plugin_active') && file_exists(ABSPATH . 'wp-admin/includes/plugin.php')) {
                include_once ABSPATH . 'wp-admin/includes/plugin.php';
            }
            if (!function_exists('is_plugin_active') || !is_plugin_active($requiredPlugin)) {
                $messages[] = 'Required plugin ' . $requiredPlugin . ' is not active.';
            }
        }

        if (!$silent) {
            foreach ($messages as $message) {
                add_action('admin_notices', function () use ($message) {
                    manny_extension_givewp_dependency_notice($message);
                });
            }
        }

        return empty($messages);
    }
}

$manny_extension_givewp_dependencies_met = manny_extension_givewp_check_dependencies();

add_action('manny_register_extension', function ($registry) use ($manny_extension_givewp_dependencies_met) {
    if (!$manny_extension_givewp_dependencies_met) {
        return;
    }

    $providerClass = 'Manny\RestRouteManager\Extensions\GiveWpExtensionProvider';

    if (!class_exists($providerClass)) {
        add_action('admin_notices', static function () use ($providerClass) {
            manny_extension_givewp_dependency_notice(
                'This Manny extension package is incompatible with the active Manny version: provider class ' . $providerClass . ' is missing.'
            );
        });

        return;
    }

    try {
        $provider = new $providerClass();
    } catch (\Throwable $throwable) {
        manny_extension_givewp_dependency_notice('Failed to initialize extension provider: ' . $throwable->getMessage());

        return;
    }

    if (is_object($registry) && method_exists($registry, 'register')) {
        $registry->register($provider, 'external');
    }
}, 10, 1);
